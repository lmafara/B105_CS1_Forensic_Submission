import sqlite3, csv

CORE = {
0:'LINK',
1:'TYPED',
2:'AUTO_BOOKMARK',
3:'AUTO_SUBFRAME',
4:'MANUAL_SUBFRAME',
5:'GENERATED',
6:'START_PAGE',
7:'FORM_SUBMIT',
8:'RELOAD',
9:'KEYWORD',
10:'KEYWORD_GENERATED'
}

QUALS = [
(0x00800000,'BLOCKED'),
(0x01000000,'FORWARD_BACK'),
(0x02000000,'FROM_ADDRESS_BAR'),
(0x04000000,'HOME_PAGE'),
(0x08000000,'FROM_API'),
(0x10000000,'CHAIN_START'),
(0x20000000,'CHAIN_END'),
(0x40000000,'CLIENT_REDIRECT'),
(0x80000000,'SERVER_REDIRECT')
]

def decode(t):
core = CORE.get(t & 0xFF, f'UNK({t & 0xFF})')
quals = [name for bit, name in QUALS if t & bit]
return core, '+'.join(quals)

con = sqlite3.connect('file:working/History_main.sqlite?mode=ro', uri=True)
cur = con.cursor()

cur.execute('''
SELECT v.id,
datetime(v.visit_time/1000000-11644473600,'unixepoch'),
u.url,
u.title,
v.transition,
v.from_visit,
v.visit_duration
FROM visits v
JOIN urls u ON v.url=u.id
ORDER BY v.visit_time
''')

with open('queries/05_decoded_transitions.csv','w',newline='') as f:
w = csv.writer(f)
w.writerow([
'visit_id',
'visit_time_utc',
'core_type',
'qualifiers',
'from_visit',
'visit_duration',
'url',
'title'
])

for vid, vt, url, title, trans, fromv, dur in cur.fetchall():
core, quals = decode(trans)
w.writerow([vid, vt, core, quals, fromv, dur, url, title])

con.close()
